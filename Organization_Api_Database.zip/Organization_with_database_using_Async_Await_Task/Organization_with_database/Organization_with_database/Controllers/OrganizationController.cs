﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Mediators.OrganizationHandler;

namespace Organization_with_database.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController : ControllerBase
    {
        private readonly IMediator _mediator;

        public OrganizationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<List<Organization>> GetAllOrganization(int pageNumber=1,int pageSize=10)
        {
            try
            {
                var request = new GetAllOrganizationRequest(pageNumber,pageSize);
                return await _mediator.Send(request);
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while getting the organizations");
            }
        }

        [HttpGet("{id}")]
        public async Task<Organization> GetByOrganizationId(Guid id)
        {
            try
            {
                var request = new GetOrganizationByIdRequest(id);
                return await _mediator.Send(request);
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while retrieving the organization");
            }
        }

        [HttpPost]
        public async Task<Organization> AddOrganization(OrganizationDTO organizationDTO)
        {
            try
            {
                var request = new CreateOrganizationRequest(organizationDTO);
                return await _mediator.Send(request);
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while adding the organization");
            }
        }
    }
}
