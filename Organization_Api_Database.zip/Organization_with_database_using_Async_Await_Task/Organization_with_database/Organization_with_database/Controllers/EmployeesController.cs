﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Mediators.EmployeeHandler;
using Organization_with_database.Repositries;
using Organization_with_database.Data;
using Mapster;

namespace Organization_with_database.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IMediator _mediator;
            
        public EmployeesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<List<Employee>> GetAllEmployees(int PageNumber=1,int PageSize=10)
        {
            var request = new GetAllEmployeeRequest(PageNumber,PageSize);
            return await _mediator.Send(request);
        }

        [HttpPost]
        public async Task<Employee> AddEmployee(EmployeesDTO employeesDTO)
        {
            var request = new CreateEmployeeRequest(employeesDTO);
            return await _mediator.Send(request);
        }

        [HttpGet("{id}")]
        public async Task<Employee> GetEmployeeById(Guid id)
        {
            var request = new GetEmployeeByIdRequest(id);
            return await _mediator.Send(request);
        }

        [HttpPut("{id}")]
        public async Task<Employee> UpdateEmployee(EmployeesDTO employeeDTO)
        {
            var request = new UpdateEmployeeRequest(employeeDTO);
            return await _mediator.Send(request);
        }

        [HttpDelete("{id}")]
        public async Task<Guid> DeleteEmployee(Guid id)
        {
            var request = new DeleteEmployeeRequest(id);
            return await _mediator.Send(request);
        }
    }
}
