﻿using Mapster;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Organization_with_database.DTO;
using Organization_with_database.Mediators.MemberHandler;
using Organization_with_database.Models;
using Organization_with_database.Repositries;

namespace Organization_with_database.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IMemberRepository _memberRepository;
        private readonly ITeamRepository _teamRepository;

        public MemberController(IMediator mediator, IMemberRepository memberRepository, ITeamRepository teamRepository)
        {
            _mediator = mediator;
            _memberRepository = memberRepository;
            _teamRepository = teamRepository;
        }

        [HttpPost]
        public async Task<Member> AddMember(MembersDTO memberDTO)
        {
            var request = new CreateMemberRequest(memberDTO);
            var member = await _mediator.Send(request);
            return member;
        }

        [HttpGet]
        public async Task<List<Member>> GetAllMembers(int pageNumber=1,int pageSize=10)
        {
            var request = new GetMemberListRequest(pageNumber,pageSize);
            var members = await _mediator.Send(request);
            return members;
        }

        [HttpGet("{id}")]
        public async Task<Member> GetMemberById(Guid id)
        {
            var request = new GetMemberByIdRequest(id);
            var member = await _mediator.Send(request);
            return member;
        }

        [HttpPut("{id}")]
        public async Task<Member> UpdateMember(Guid id, MembersDTO memberDTO)
        {
            var request = new UpdateMemberRequest(id, memberDTO);
            var updatedMember = await _mediator.Send(request);
            return updatedMember;
        }

        [HttpDelete("{id}")]
        public async Task<Guid> DeleteMember(Guid id)
        {
            var request = new DeleteMemberRequest(id);
            await _mediator.Send(request);
            return id;
        }

        [HttpPut("changeRole/{memberId}")]
        public async Task<Member> ChangeRole(Guid memberId, string newRole)

        {
            var request = new ChangeMemberRoleRequest(memberId, newRole);
            var result = await _mediator.Send(request);
            return result;
        }
        [HttpPut("ReassignMember/{memberId}/to/{newTeamId}")]
        public async Task<Member> ReassignMember(Guid memberId, Guid newTeamId)
        {
            var request = new ReassignMemberRequest(memberId,newTeamId);
            var result = await _mediator.Send(request);
            return result;
        }
    }
}
