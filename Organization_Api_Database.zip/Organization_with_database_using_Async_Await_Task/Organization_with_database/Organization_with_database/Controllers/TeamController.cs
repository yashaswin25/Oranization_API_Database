﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Organization_with_database.Models;
using Organization_with_database.Mediators.TeamHandler;
using Organization_with_database.Repositries;

namespace Organization_with_database.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamsController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ITeamRepository _teamRepository;
        public TeamsController(IMediator mediator,ITeamRepository teamRepository)
        {
            _mediator = mediator;
            _teamRepository = teamRepository;
        }

        [HttpGet]
        public async Task<List<Team>> GetAllTeams(int pageNumber=1,int pageSize=10)
        {
            var request = new GetAllTeamsRequest(pageNumber,pageSize);
            return await _mediator.Send(request);
        }

        [HttpPost]
        public async Task<Team> AddTeam(Team team)
        {
            var request = new CreateTeamRequest(team);
            return await _mediator.Send(request);
        }

        [HttpGet("{id}")]
        public async Task<Team> GetTeamById(Guid id)
        {
            var request = new GetTeamByIdRequest(id);
            return await _mediator.Send(request);
        }

        [HttpGet("getByManager/{managerId}")]
        public async Task<List<Team>> GetTeamsByManager(Guid managerId)
        {
            var request = new GetTeamsByManagerRequest(managerId);
            return await _mediator.Send(request);
        }

        [HttpGet("getTotalEfforts/{id}")]
        public async Task<string> GetTotalEfforts(Guid id)
        {
            try
            {
                var team = await _teamRepository.GetTeamById(id);
                var members = team.Members;
                var totalHoursWorked = members?.Sum(member => member.HoursWorked) ?? 0;
                return $"Total hours worked by {team.Name} team: {totalHoursWorked}";
            }
            catch (Exception)
            {
                throw new Exception($"error occurred while getting total efforts");
            }
        }

        [HttpGet("GetTeamNameByManager/{managerId}")]
        public async Task<List<string>> GetTeamNameByManager(Guid managerId)
        {
            var request = new GetTeamNameByManagerRequest(managerId);
            return await _mediator.Send(request);
        }
    }
}
