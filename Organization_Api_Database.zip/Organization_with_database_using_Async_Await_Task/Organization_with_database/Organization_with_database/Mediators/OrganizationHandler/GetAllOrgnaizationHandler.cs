﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.OrganizationSpec;

namespace Organization_with_database.Mediators.OrganizationHandler
{
    public class GetAllOrganizationRequest : IRequest<List<Organization>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public GetAllOrganizationRequest(int pageNumber=1,int pageSize=10)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }
    }
    public class GetAllOrgnaizationHandler : IRequestHandler<GetAllOrganizationRequest, List<Organization>>
    {
        private readonly IGenericRepository<Organization> _OrganizationRepository;
        public GetAllOrgnaizationHandler(IGenericRepository<Organization> organizationRepository)
        {
            _OrganizationRepository = organizationRepository;
        }
        public async Task<List<Organization>> Handle(GetAllOrganizationRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetAllOrganizationSpecification(request.PageNumber,request.PageSize);
            var organization =  await _OrganizationRepository.GetAllAsync(spec);
            return organization;
        }
    }
}
