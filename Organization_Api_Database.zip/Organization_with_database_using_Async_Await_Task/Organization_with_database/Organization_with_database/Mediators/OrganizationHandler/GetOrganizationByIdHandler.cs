﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.OrganizationSpec;

namespace Organization_with_database.Mediators.OrganizationHandler
{
    public class GetOrganizationByIdRequest : IRequest<Organization>
    {
        public Guid Id { get; set; }
        public GetOrganizationByIdRequest(Guid id)
        {
            Id = id;
        }
    }
    public class GetOrganizationByIdHandler : IRequestHandler<GetOrganizationByIdRequest, Organization>
    {
        private readonly IGenericRepository<Organization> _organizationRepository;
        public GetOrganizationByIdHandler(IGenericRepository<Organization> organizationRepository)
        {
            _organizationRepository = organizationRepository;
        }
        public Task<Organization> Handle(GetOrganizationByIdRequest request, CancellationToken cancellationToken)
        {
            var spec = new getBYOrgnaizationIdSpecification(request.Id);
            var org = _organizationRepository.GetIdAsync(request.Id,spec);
            if (org == null)
            {
                throw new NullReferenceException("Organization Not Found");
            }
            return org;
        }
    }
}
