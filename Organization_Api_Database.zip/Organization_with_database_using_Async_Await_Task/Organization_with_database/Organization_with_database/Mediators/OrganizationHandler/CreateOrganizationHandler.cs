﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Repositries;

namespace Organization_with_database.Mediators.OrganizationHandler
{
    public class CreateOrganizationRequest : IRequest<Organization>
    {
        public OrganizationDTO OrganizationDTO { get; set; }
        public CreateOrganizationRequest(OrganizationDTO organizationDTO)
        {
            OrganizationDTO = organizationDTO;
        }
    }
    public class CreateOrganizationHandler : IRequestHandler<CreateOrganizationRequest, Organization>
    {
        private readonly IGenericRepository<Organization> _organizationRepository;
        public CreateOrganizationHandler(IGenericRepository<Organization> organizationRepository)
        {
            _organizationRepository = organizationRepository;
        }
        public async Task<Organization> Handle(CreateOrganizationRequest request, CancellationToken cancellationToken)
        {
            var organization = request.OrganizationDTO.Adapt<Organization>();
            return await _organizationRepository.AddAsync(organization);
        }
    }
}
