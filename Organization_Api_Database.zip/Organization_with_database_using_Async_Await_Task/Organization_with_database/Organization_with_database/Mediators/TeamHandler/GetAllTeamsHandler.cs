﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.TeamSpecification;

namespace Organization_with_database.Mediators.TeamHandler
{
    public class GetAllTeamsRequest : IRequest<List<Team>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public GetAllTeamsRequest(int pageNumber=1,int pageSize=10)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }
    }
    public class GetAllTeamsHandler : IRequestHandler<GetAllTeamsRequest, List<Team>>
    {
        public readonly IGenericRepository<Team> _teamRepository;
        public GetAllTeamsHandler(IGenericRepository<Team> teamRepository)
        {
            _teamRepository = teamRepository;
        }
        public async Task<List<Team>> Handle(GetAllTeamsRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetAllTeamSpecification(request.PageNumber, request.PageSize);
            var team =  await _teamRepository.GetAllAsync(spec);
            return team;
        }
    }
}
