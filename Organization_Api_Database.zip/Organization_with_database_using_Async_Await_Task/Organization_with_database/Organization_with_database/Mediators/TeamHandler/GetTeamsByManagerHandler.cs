﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;

namespace Organization_with_database.Mediators.TeamHandler
{
    public class GetTeamsByManagerRequest : IRequest<List<Team>>
    {
        public Guid ManagerId { get; set; }
        public GetTeamsByManagerRequest(Guid managerId)
        {
            ManagerId = managerId;
        }
    }
    public class GetTeamsByManagerHandler : IRequestHandler<GetTeamsByManagerRequest, List<Team>>
    {
        public readonly ITeamRepository _teamRepository;
        public GetTeamsByManagerHandler(ITeamRepository teamRepository)
        {
            _teamRepository = teamRepository;
        }
        public async Task<List<Team>> Handle(GetTeamsByManagerRequest request, CancellationToken cancellationToken)
        {
            var team = await _teamRepository.GetTeamsByManagerId(request.ManagerId);
            if (team == null)
            {
                throw new Exception("Team not found for this manager");
            }
            return team;
        }
    }
}
