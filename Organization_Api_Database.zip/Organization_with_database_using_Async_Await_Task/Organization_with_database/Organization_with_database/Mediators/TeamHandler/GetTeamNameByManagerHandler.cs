﻿using MediatR;
using Organization_with_database.Repositries;

namespace Organization_with_database.Mediators.TeamHandler
{
    public class GetTeamNameByManagerRequest : IRequest<List<string>>
    {
        public Guid ManagerId { get; set; }
        public GetTeamNameByManagerRequest(Guid managerId)
        {
            ManagerId = managerId;
        }
    }
    public class GetTeamNameByManagerHandler : IRequestHandler<GetTeamNameByManagerRequest, List<string>>
    {
        public readonly ITeamRepository _teamRepository;
        public GetTeamNameByManagerHandler(ITeamRepository teamRepository)
        {
            _teamRepository = teamRepository;
        }

        public async Task<List<string>> Handle(GetTeamNameByManagerRequest request, CancellationToken cancellationToken)
        {
            var team = await _teamRepository.GetTeamNameByManagerId(request.ManagerId);
            if (team == null)
            {
                throw new NullReferenceException("Team Not Found");
            }
            return team.Select(x => x.Name).ToList();
        }
    }
}
