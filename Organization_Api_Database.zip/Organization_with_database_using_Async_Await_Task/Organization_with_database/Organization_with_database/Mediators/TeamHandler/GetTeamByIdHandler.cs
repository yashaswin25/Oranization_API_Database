﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.TeamSpecification;

namespace Organization_with_database.Mediators.TeamHandler
{

    public class GetTeamByIdRequest : IRequest<Team>
    {
        public Guid Id { get; set; }
        public GetTeamByIdRequest(Guid id)
        {
            Id = id;
        }
    }
    public class GetTeamByIdHandler : IRequestHandler<GetTeamByIdRequest, Team>
    {
        public readonly IGenericRepository<Team> _teamRepository;
        public GetTeamByIdHandler(IGenericRepository<Team> teamRepository)
        {
            _teamRepository = teamRepository;
        }

        public Task<Team> Handle(GetTeamByIdRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByTeamIdSpecification(request.Id);
            var team = _teamRepository.GetIdAsync(request.Id,spec);
            if (team == null)
            {
                throw new NullReferenceException("Team Not Found");
            }
            return team;
        }
    }
}
