﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;

namespace Organization_with_database.Mediators.TeamHandler
{
    public class CreateTeamRequest : IRequest<Team>
    {
        public Team Team { get; set; }
        public CreateTeamRequest(Team team)
        {
            Team = team;
        }
    }
    public class CreateTeamHandler : IRequestHandler<CreateTeamRequest, Team>
    {
        public readonly IGenericRepository<Team> _teamRepository;
        public CreateTeamHandler(IGenericRepository<Team> teamRepository)
        {
            _teamRepository = teamRepository;
        }
        public async Task<Team> Handle(CreateTeamRequest request, CancellationToken cancellationToken)
        {
            var team = request.Team;
            return await _teamRepository.AddAsync(team);
        }
    }
}
