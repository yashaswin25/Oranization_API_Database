﻿using MediatR;
using Organization_with_database.Mediators.MemberHandler;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class DeleteMemberRequest : IRequest<Guid>
    {
        public Guid Id { get; set; }
        public DeleteMemberRequest(Guid id)
        {
            Id = id;
        }
    }
    public class DeleteMemberHandler : IRequestHandler<DeleteMemberRequest, Guid>
    {
        private readonly IGenericRepository<Member> _memberRepository;

        public DeleteMemberHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<Guid> Handle(DeleteMemberRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByMembersIdSpecification(request.Id);
            var member = await _memberRepository.GetIdAsync(request.Id, spec);
            if (member == null)
            {
                throw new NullReferenceException("Member Not Found");
            }
            await _memberRepository.DeleteAsync(request.Id);
            return request.Id;
        }
    }
}
