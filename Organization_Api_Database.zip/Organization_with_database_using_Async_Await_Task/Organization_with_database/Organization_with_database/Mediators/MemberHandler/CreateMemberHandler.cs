﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Repositries;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class CreateMemberRequest : IRequest<Member>
    {
        public MembersDTO MemberDTO { get; set; }
        public CreateMemberRequest(MembersDTO membersDTO)
        {
            MemberDTO = membersDTO;
        }
    }
    public class CreateMemberHandler : IRequestHandler<CreateMemberRequest, Member>
    {
        private readonly IGenericRepository<Member> _memberRepository;
        public CreateMemberHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }

        public async Task<Member> Handle(CreateMemberRequest request, CancellationToken cancellationToken)
        {
            var member = request.MemberDTO.Adapt<Member>();
            var createdmeber = await _memberRepository.AddAsync(member);
            return createdmeber;
        }
    }
}
