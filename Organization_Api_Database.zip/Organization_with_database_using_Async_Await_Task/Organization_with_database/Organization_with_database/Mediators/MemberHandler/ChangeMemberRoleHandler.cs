﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class ChangeMemberRoleRequest : IRequest<Member>
    {
        public Guid MemberId { get; set; }
        public String NewRole {  get; set; }
        public ChangeMemberRoleRequest(Guid memberId,String newRole)
        {
            MemberId = memberId;
            NewRole = newRole;
        }
    }
    public class ChangeMemberRoleHandler : IRequestHandler<ChangeMemberRoleRequest, Member>
    {
        private readonly IGenericRepository<Member> _memberRepository;
        public ChangeMemberRoleHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<Member> Handle(ChangeMemberRoleRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByMembersIdSpecification(request.MemberId);
            var member = await _memberRepository.GetIdAsync(request.MemberId, spec);
            member.Role = request.NewRole;
            return await _memberRepository.UpdateAsync(member);
        }
    }
}
