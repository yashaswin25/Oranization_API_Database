﻿using MediatR;
using Organization_with_database.Mediators.EmployeeHandler;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class GetMemberByIdRequest : IRequest<Member>
    {
        public Guid Id { get; set; }
        public GetMemberByIdRequest(Guid id)
        {
            Id = id;
        }
    }
    public class GetMemberByIdHandler : IRequestHandler<GetMemberByIdRequest, Member>
    {
        private readonly IGenericRepository<Member> _memberRepository;
        public GetMemberByIdHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public Task<Member> Handle(GetMemberByIdRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByMembersIdSpecification(request.Id);
            var member = _memberRepository.GetIdAsync(request.Id,spec);
            if (member == null)
            {
                throw new NullReferenceException("Member not Found");
            }
            return member;
        }
    }
}
