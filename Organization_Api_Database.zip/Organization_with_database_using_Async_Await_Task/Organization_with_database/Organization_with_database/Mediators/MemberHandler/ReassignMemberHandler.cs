﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Mediators.MemberHandler;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class ReassignMemberRequest:IRequest<Member>
    {
        public Guid MemberId { get; set; }  
        public Guid NewTeamId { get; set; }
        public ReassignMemberRequest(Guid memberId,Guid newTeamId) 
        {
            MemberId= memberId;
            NewTeamId= newTeamId;
        }
    }
}

public class ReassignMemberHandler : IRequestHandler<ReassignMemberRequest, Member>
{
    private readonly IGenericRepository<Member> _memberRepository;
    private readonly ITeamRepository _teamRepository;
    public ReassignMemberHandler(IGenericRepository<Member> memberRepository,ITeamRepository teamRepository)
    {
        _memberRepository= memberRepository;
        _teamRepository= teamRepository;
    }
    public async Task<Member> Handle(ReassignMemberRequest request, CancellationToken cancellationToken)
    {
        var spec = new GetByMembersIdSpecification(request.MemberId);
        var member = await _memberRepository.GetIdAsync(request.MemberId,spec);
        var currentTeam = await _teamRepository.GetTeamById(member.TeamId);
        var newTeam = await _teamRepository.GetTeamById(request.NewTeamId);
        currentTeam.Members?.Remove(member);
        member.TeamId = request.NewTeamId;
        member.ReportsTo = newTeam.ManagerId;
  
        await _memberRepository.UpdateAsync(member);
        return member;
    }
}
