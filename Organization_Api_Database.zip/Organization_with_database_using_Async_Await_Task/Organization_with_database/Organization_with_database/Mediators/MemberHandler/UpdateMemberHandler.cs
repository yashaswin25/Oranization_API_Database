﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class UpdateMemberRequest : IRequest<Member>
    {
        public Guid Id { get; set; }
        public MembersDTO MemberDTO { get; set; }
        public UpdateMemberRequest(Guid id, MembersDTO memberDTO)
        {
            Id = id;
            MemberDTO = memberDTO;
        }
    }
    public class UpdateMemberHandler : IRequestHandler<UpdateMemberRequest, Member>
    {
        private readonly IGenericRepository<Member> _memberRepository;
        public UpdateMemberHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<Member> Handle(UpdateMemberRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByMembersIdSpecification(request.Id);
            var member = await _memberRepository.GetIdAsync(request.Id,spec);
            if (member == null)
            {
                throw new NullReferenceException("Member Not Found");
            }
            var updateMember = request.MemberDTO.Adapt(member);
            await _memberRepository.UpdateAsync(updateMember);
            return updateMember;
        }
    }
}
