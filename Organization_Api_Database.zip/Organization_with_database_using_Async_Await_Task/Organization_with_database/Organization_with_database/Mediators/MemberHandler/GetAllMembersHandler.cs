﻿using MediatR;
using Organization_with_database.Mediators.EmployeeHandler;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.MemberHandler
{
    public class GetMemberListRequest : IRequest<List<Member>>
    {
        public int PageNumber { get; set; }
        public int  PageSize { get; set; }
        public GetMemberListRequest(int pageNumber=1,int pageSize=10)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }

    }
    public class GetAllMembersHandler : IRequestHandler<GetMemberListRequest, List<Member>>
    {
        private readonly IGenericRepository<Member> _memberRepository;

        public GetAllMembersHandler(IGenericRepository<Member> memberRepository)
        {
            _memberRepository = memberRepository;
        }
        public async Task<List<Member>> Handle(GetMemberListRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetAllMembersSpecification(request.PageNumber,request.PageSize);
            var member = await _memberRepository.GetAllAsync(spec);
            return member;
        }
    }
}
