﻿using Mapster;
using MediatR;
using Organization_with_database.DTO;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.EmployeeSpecification;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.EmployeeHandler
{
    public class UpdateEmployeeRequest : IRequest<Employee>
    {
        public EmployeesDTO EmployeeDTO { get; set; }

        public UpdateEmployeeRequest(EmployeesDTO employeeDTO)
        {
            EmployeeDTO = employeeDTO;
        }
    }
    public class UpdateEmployeehandler : IRequestHandler<UpdateEmployeeRequest, Employee>
    {
        private readonly IGenericRepository<Employee> _employeRepository;
        public UpdateEmployeehandler(IGenericRepository<Employee> employeeRepository)
        {
            _employeRepository = employeeRepository;
        }

        public async Task<Employee> Handle(UpdateEmployeeRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByEmployeeIdSpecification(request.EmployeeDTO.Id);
            var employee = await _employeRepository.GetIdAsync(request.EmployeeDTO.Id,spec);
            if (employee == null)
            {
                throw new NullReferenceException("Employee Not Found");
            }
            var updateEmployee = request.EmployeeDTO.Adapt(employee);
            await _employeRepository.UpdateAsync(updateEmployee);
            return employee;
        }
    }
}