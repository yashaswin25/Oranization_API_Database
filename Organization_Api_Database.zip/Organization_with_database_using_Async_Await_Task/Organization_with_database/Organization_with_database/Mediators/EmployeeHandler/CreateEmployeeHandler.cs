﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Mapster;
using Organization_with_database.DTO;
namespace Organization_with_database.Mediators.EmployeeHandler
{
    public class CreateEmployeeRequest : IRequest<Employee>
    {
        public EmployeesDTO EmployeesDTO { get; set; }

        public CreateEmployeeRequest(EmployeesDTO employeesDTO)
        {
            EmployeesDTO = employeesDTO;
        }
    }
    public class CreateEmployeeHandler : IRequestHandler<CreateEmployeeRequest, Employee>
    {
        private readonly IGenericRepository<Employee> _employeeRepository;
        public CreateEmployeeHandler(IGenericRepository<Employee> employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public async Task<Employee> Handle(CreateEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = request.EmployeesDTO.Adapt<Employee>();
            var addedEmployee = await _employeeRepository.AddAsync(employee);
            return addedEmployee;
        }
    }
}
