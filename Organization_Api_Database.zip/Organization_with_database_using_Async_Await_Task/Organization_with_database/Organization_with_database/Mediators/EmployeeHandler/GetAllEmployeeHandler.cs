﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.EmployeeSpecification;

namespace Organization_with_database.Mediators.EmployeeHandler
{
    public class GetAllEmployeeRequest : IRequest<List<Employee>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public GetAllEmployeeRequest(int pageNumber = 1, int pageSize = 10)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }
    }
    public class GetAllEmployeeHandler : IRequestHandler<GetAllEmployeeRequest, List<Employee>>
    {
        private readonly IGenericRepository<Employee> _employeeRepository;
        public GetAllEmployeeHandler(IGenericRepository<Employee> employeeRepository) 
        {
            _employeeRepository = employeeRepository;
        }
        public async Task<List<Employee>> Handle(GetAllEmployeeRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetAllEmployeesSpecification(request.PageNumber, request.PageSize);
            var employee =  await _employeeRepository.GetAllAsync(spec);
            return employee;
        }
    }
}
