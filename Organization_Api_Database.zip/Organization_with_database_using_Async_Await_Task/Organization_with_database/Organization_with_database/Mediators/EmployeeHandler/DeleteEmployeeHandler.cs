﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.EmployeeSpecification;
using Organization_with_database.Specification.MembersSpecification;

namespace Organization_with_database.Mediators.EmployeeHandler
{
    public class DeleteEmployeeRequest : IRequest<Guid>
    {
        public Guid Id { get; set; }
        public DeleteEmployeeRequest(Guid id)
        {
            Id = id;
        }
    }
    public class DeleteEmployeeHandler : IRequestHandler<DeleteEmployeeRequest, Guid>
    {
        private readonly IGenericRepository<Employee> _employeeRepository;
        public DeleteEmployeeHandler(IGenericRepository<Employee> employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public async Task<Guid> Handle(DeleteEmployeeRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByEmployeeIdSpecification(request.Id);
            var emp = await _employeeRepository.GetIdAsync(request.Id,spec);
            if (emp == null)
            {
                throw new NullReferenceException("Employee Not Found");
            }
            await _employeeRepository.DeleteAsync(request.Id);
            return emp.Id;
        }
    }
}
