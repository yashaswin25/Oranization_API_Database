﻿using MediatR;
using Organization_with_database.Models;
using Organization_with_database.Repositries;
using Organization_with_database.Specification.EmployeeSpecification;

namespace Organization_with_database.Mediators.EmployeeHandler
{
    public class GetEmployeeByIdRequest : IRequest<Employee>
    {
        public Guid Id { get; set; }
        public GetEmployeeByIdRequest(Guid id)
        {
            Id = id;
        }
    }
    public class GetEmployeeByIdHandler : IRequestHandler<GetEmployeeByIdRequest, Employee>
    {
        private readonly IGenericRepository<Employee> _employeeRepository;
        public GetEmployeeByIdHandler(IGenericRepository<Employee> employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public Task<Employee> Handle(GetEmployeeByIdRequest request, CancellationToken cancellationToken)
        {
            var spec = new GetByEmployeeIdSpecification(request.Id);
            var employee = _employeeRepository.GetIdAsync(request.Id, spec);
            return employee;
        }
    }
}