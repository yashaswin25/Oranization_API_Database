﻿using Organization_with_database.Models;
using Organization_with_database.DTO;
namespace Organization_with_database.Repositries
{
    public interface IEmployeeRepository
    {
        public Task<List<Employee>> GetAll(int pageNumber,int pageSize);
        public Task<Employee> GetById(Guid id);
        public Task<Employee> Add(Employee employee);
        public Task<Employee> Update(Guid id, EmployeesDTO employeeDTO);
        public Task<Employee> Delete(Guid id);
        public Task<CalculateSalaryDTO> CalculateSalary(Guid employeeId, int numberOfLeaves);
    }

}
