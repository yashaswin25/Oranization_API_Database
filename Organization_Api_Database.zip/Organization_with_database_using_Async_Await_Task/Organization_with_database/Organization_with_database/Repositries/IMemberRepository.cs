﻿using Organization_with_database.Models;
using Organization_with_database.DTO;
namespace Organization_with_database.Repositries
{
    public interface IMemberRepository
    {
        public Task<List<Member>> GetAll(int pageNumber=1,int pageSize=10);
        public Task<Member> GetMemberById(Guid id);
        public Task DeleteMember(Guid id);
        public Task<Member> AddMember(Member member);
        public Task<Member> UpdateMember(Guid id, MembersDTO memberDTO);
    }
}
