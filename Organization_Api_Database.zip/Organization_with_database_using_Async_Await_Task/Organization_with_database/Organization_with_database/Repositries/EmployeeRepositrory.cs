﻿using Organization_with_database.Models;
using Organization_with_database.DTO;
using Mapster;
using Organization_with_database.Data;
using Microsoft.EntityFrameworkCore;
using Ardalis.Specification.EntityFrameworkCore;
using Organization_with_database.Specification.EmployeeSpecification;
namespace Organization_with_database.Repositries
{
    public class EmployeeRepositrory : IEmployeeRepository
    {
        private readonly ApplicationDBContext _applicationDBContext;
        public EmployeeRepositrory(ApplicationDBContext applicationDBContext)
        {
            _applicationDBContext = applicationDBContext;
        }
        public async Task<Employee> Add(Employee employee)
        {
            employee.Id = Guid.NewGuid();
            await _applicationDBContext.Employees.AddAsync(employee);
            await _applicationDBContext.SaveChangesAsync();
            return employee;
        }

        public async Task<Employee> Delete(Guid id)
        {
            var employee = await _applicationDBContext.Employees.FirstOrDefaultAsync(x=>x.Id==id);
            if (employee == null)
            {
                throw new Exception("Employe not found");
            }
            _applicationDBContext.Employees.Remove(employee);
            await _applicationDBContext.SaveChangesAsync();
            return employee;
        }

        public async Task<List<Employee>> GetAll(int pageNumber,int pageSize)
        {
            var query = new GetAllEmployeesSpecification(pageNumber,pageSize);
            var employee = await _applicationDBContext.Employees.WithSpecification(query).ToListAsync();
            return  employee;
        }

        public async Task<Employee> GetById(Guid id)
        {
            var query = new GetByEmployeeIdSpecification(id);
            var employe = await _applicationDBContext.Employees.WithSpecification(query).FirstOrDefaultAsync();
            if(employe == null)
            {
                throw new NullReferenceException("Employee Not Found");
            }
            return employe;
        }   

        public async Task<Employee> Update(Guid id, EmployeesDTO employeeDTO)
        {
            var user = await _applicationDBContext.Employees.Where(i=>i.IsDeleted==false).FirstOrDefaultAsync(s => s.Id == id);
            if (user != null)
            {
                employeeDTO.Adapt(user);
                await _applicationDBContext.SaveChangesAsync();
                return user;
            }
            else
            {
                throw new Exception("employe not found");
            }
        }
        
        public async Task<CalculateSalaryDTO> CalculateSalary(Guid employeeId, int numberOfLeaves)
        {
            var employee = await _applicationDBContext.Employees.Where(i => i.IsDeleted == false).FirstOrDefaultAsync(p => p.Id == employeeId);
            if (employee == null)
            {
                throw new Exception("Employee not found");
            }
            int noOfLeaves = employee.NoOfLeaves ?? 0;
            double dailyPay = (double)employee.Salary / 30;
            double deducted = dailyPay * noOfLeaves;
            double finalsalary = (double)employee.Salary - deducted;

            return new CalculateSalaryDTO
            {
                EmployeeId = employee.Id,
                OriginalSalary = employee.Salary,
                DeductedAmount = deducted,
                FinalSalary = finalsalary
            };
        }
    }
}
