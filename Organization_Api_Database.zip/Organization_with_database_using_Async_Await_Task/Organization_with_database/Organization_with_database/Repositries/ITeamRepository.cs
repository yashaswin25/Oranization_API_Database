﻿using Organization_with_database.Models;

namespace Organization_with_database.Repositries
{
    public interface ITeamRepository
    {
        public Task<List<Team>> GetTeams(int pageNumber=1,int pageSize=10);
        public Task<Team> GetTeamById(Guid id);
        public Task<Team> Add(Team team);
        public Task<List<Team>> GetTeamsByManagerId(Guid managerId); 
        public Task<List<Team>> GetTeamNameByManagerId(Guid managerId);
    }
}
