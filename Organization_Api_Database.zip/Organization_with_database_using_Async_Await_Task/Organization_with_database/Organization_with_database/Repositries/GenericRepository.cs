﻿
using Microsoft.EntityFrameworkCore;
using Organization_with_database.Data;
using Organization_with_database.Specification.EmployeeSpecification;
using Ardalis.Specification.EntityFrameworkCore;
using Ardalis.Specification;


namespace Organization_with_database.Repositries
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDBContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public GenericRepository(ApplicationDBContext applicationDBContext)
        {
            _dbContext = applicationDBContext;
            _dbSet = _dbContext.Set<T>();
        }
        public async Task<T> AddAsync(T entity)
        {
            await _dbSet.AddAsync(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<T> DeleteAsync(Guid id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null)
            {
                throw new NullReferenceException("Employee Not Found");
            }
            _dbSet.Remove(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<List<T>> GetAllAsync(ISpecification<T> spec)
        {
            return await _dbContext.Set<T>().WithSpecification(spec).ToListAsync();
        }

        public async Task<T> GetIdAsync(Guid id, ISpecification<T> spec)
        {
            var entity = await _dbSet
                .WithSpecification(spec)
                .FirstOrDefaultAsync(e => EF.Property<Guid>(e, "Id") == id);

            if (entity == null)
            {
                throw new NullReferenceException("Entity Not Found");
            }
            return entity;
        }

        public async Task<T> UpdateAsync( T entity)
        {
            var existingEntity = _dbContext.Set<T>().Update(entity);
            await _dbContext.SaveChangesAsync();
            return existingEntity.Entity;
        }
    }
}
