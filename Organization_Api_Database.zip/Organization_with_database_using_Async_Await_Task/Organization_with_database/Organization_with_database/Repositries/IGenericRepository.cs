﻿using Ardalis.Specification;

namespace Organization_with_database.Repositries
{
    public interface IGenericRepository<T> where T : class
    {
        Task<List<T>> GetAllAsync(ISpecification<T> spec);
        Task<T> GetIdAsync(Guid id, ISpecification<T> spec);
        Task<T> AddAsync(T entity);
        Task<T> DeleteAsync(Guid id);
        Task<T> UpdateAsync(T entity);
    }
}
