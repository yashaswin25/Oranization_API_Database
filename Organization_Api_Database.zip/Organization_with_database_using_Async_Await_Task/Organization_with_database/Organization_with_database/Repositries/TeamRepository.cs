﻿using Organization_with_database.Models;
using Organization_with_database.Data;
using Microsoft.EntityFrameworkCore;
using Organization_with_database.Specification.TeamSpecification;
using Ardalis.Specification.EntityFrameworkCore;
namespace Organization_with_database.Repositries
{
    public class TeamRepository:ITeamRepository
    {
        public readonly ApplicationDBContext _applicationDBContext;
        public TeamRepository(ApplicationDBContext applicationDBContext)
        {
            _applicationDBContext = applicationDBContext;
        }
        public async Task<Team> Add(Team team)
        {
            team.Id = Guid.NewGuid();
            await _applicationDBContext.Teams.AddAsync(team);
            await _applicationDBContext.SaveChangesAsync();
            return team;
        }

        public async Task<Team> GetTeamById(Guid id)
        {
            var query = new GetByTeamIdSpecification(id);
            var team = await _applicationDBContext.Teams.WithSpecification(query).FirstOrDefaultAsync();
            if(team == null)
            {
                throw new NullReferenceException("Team Not Found");
            }
            return team;
        }

        public async Task<List<Team>> GetTeamsByManagerId(Guid managerId)
        {
            var query = new GetByTeamManagerIdSpecification(managerId);
            return await _applicationDBContext.Teams.WithSpecification(query).ToListAsync();
        }

        public async Task<List<Team>> GetTeamNameByManagerId(Guid managerId)
        {
            var query = new GetByTeamManagerIdSpecification(managerId);
            return await _applicationDBContext.Teams.WithSpecification(query).ToListAsync();
        }

        public async Task<List<Team>> GetTeams(int pageNumber=1,int pageSize=10)
        {
            var query = new GetAllTeamSpecification(pageNumber,pageSize);
            return await _applicationDBContext.Teams.WithSpecification(query).ToListAsync();
        }
    }
}
