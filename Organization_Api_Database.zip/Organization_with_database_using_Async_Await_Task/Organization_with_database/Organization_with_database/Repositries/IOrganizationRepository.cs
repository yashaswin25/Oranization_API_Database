﻿using Organization_with_database.Models;

namespace Organization_with_database.Repositries
{
    public interface IOrganizationRepository
    {
        public Task<Organization> AddOrganization(Organization organization);
        public Task<Organization> GetOrganizationById(Guid id);
        public Task<List<Organization>> GetAllOrganization(int pageNumber=1,int pageSize=10);
    }
}
