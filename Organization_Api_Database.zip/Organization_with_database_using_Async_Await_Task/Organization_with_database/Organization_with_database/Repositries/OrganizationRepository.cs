﻿using Organization_with_database.Models;
using Organization_with_database.Data;
using Microsoft.EntityFrameworkCore;
using Organization_with_database.Specification.OrganizationSpec;
using Ardalis.Specification.EntityFrameworkCore;
namespace Organization_with_database.Repositries
{
    public class OrganizationRepository:IOrganizationRepository
    {
        public readonly ApplicationDBContext _applicationDBContext;
        public OrganizationRepository(ApplicationDBContext applicationDBContext)
        {
            _applicationDBContext = applicationDBContext;
        }

        public async Task<Organization> AddOrganization(Organization organization)
        {
            organization.Id = Guid.NewGuid();
            await _applicationDBContext.Organizations.AddAsync(organization);
            await _applicationDBContext.SaveChangesAsync();
            return organization;
        }

        public async Task<List<Organization>> GetAllOrganization(int pageNumber=1,int pageSize=10)
        {
            var query = new GetAllOrganizationSpecification(pageNumber,pageSize);
            return await _applicationDBContext.Organizations.WithSpecification(query).ToListAsync();
        }

        public async Task<Organization> GetOrganizationById(Guid id)
        {
            var query = new getBYOrgnaizationIdSpecification(id);
            var organization = await _applicationDBContext.Organizations.WithSpecification(query).FirstOrDefaultAsync();
            if(organization == null)
            {
                throw new NullReferenceException("Organization Not Found");
            }
            return organization;
        }   
    }
}
