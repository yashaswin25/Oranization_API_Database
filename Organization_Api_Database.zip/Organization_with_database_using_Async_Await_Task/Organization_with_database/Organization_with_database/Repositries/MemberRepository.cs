﻿using Organization_with_database.Models;
using Organization_with_database.Data;
using Organization_with_database.DTO;
using Mapster;
using Microsoft.EntityFrameworkCore;
using Organization_with_database.Specification.MembersSpecification;
using Ardalis.Specification.EntityFrameworkCore;
namespace Organization_with_database.Repositries
{
    public class MemberRepository:IMemberRepository
    {
        public readonly ApplicationDBContext _applicationDBContext;
        public MemberRepository(ApplicationDBContext applicationDBContext)
        {
            _applicationDBContext = applicationDBContext;
        }
        public async Task<Member> AddMember(Member member)
        {
            member.Id = Guid.NewGuid();
            await _applicationDBContext.Members.AddAsync(member);
            await _applicationDBContext.SaveChangesAsync();
            return member;
        }

        public async Task DeleteMember(Guid id)
        {
            var user = await _applicationDBContext.Members.FirstOrDefaultAsync(x => x.Id == id);
            if (user != null)
            {
                _applicationDBContext.Members.Remove(user);
                await _applicationDBContext.SaveChangesAsync();
            }
            else
            {
                throw new Exception("user not found");
            }
        }

        public async Task<List<Member>> GetAll(int pageNumber=1,int pageSize=10)
        {
            var query = new GetAllMembersSpecification();

            return await _applicationDBContext.Members.WithSpecification(query).Where(p=>p.IsDeleted==false).ToListAsync();
        }

        public async Task<Member> GetMemberById(Guid id)
        {
            var query = new GetByMembersIdSpecification(id);
            return await _applicationDBContext.Members.WithSpecification(query).FirstOrDefaultAsync();
        }

        public async Task<Member> UpdateMember(Guid id, MembersDTO memberDTO)
        {
            var existingMember = await _applicationDBContext.Members.Where(i => i.IsDeleted == false).FirstOrDefaultAsync(x => x.Id == id);
            if (existingMember == null)
            {
                throw new Exception("Member not found");
            }
            memberDTO.Adapt(existingMember);
            await _applicationDBContext.SaveChangesAsync();
            return existingMember;
        }
    }
}
