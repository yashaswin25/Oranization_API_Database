﻿namespace Organization_with_database.Repositries
{
    public class Class
    {
    }
}
