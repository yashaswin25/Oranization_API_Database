﻿using Ardalis.Specification;
using Organization_with_database.Models;


namespace Organization_with_database.Specification.TeamSpecification
{
    public class GetByTeamManagerIdSpecification:Specification<Team>
    {
        public GetByTeamManagerIdSpecification(Guid managerId)
        {
            Query.Where(q => q.ManagerId == managerId).Include(p=>p.Members.Where(i=>i.IsDeleted==false));   
        }
    }
}
