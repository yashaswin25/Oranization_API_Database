﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.TeamSpecification
{
    public class GetByTeamIdSpecification:Specification<Team>
    {
        public GetByTeamIdSpecification(Guid teamId)
        {
            Query.Include(p => p.Members.Where(i=>i.IsDeleted==false)).Where(q => q.Id == teamId);
        }
    }
}
