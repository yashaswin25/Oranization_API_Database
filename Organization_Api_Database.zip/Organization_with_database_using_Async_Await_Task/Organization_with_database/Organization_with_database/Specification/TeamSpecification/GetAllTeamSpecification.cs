﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.TeamSpecification
{
    public class GetAllTeamSpecification:Specification<Team>
    {
        public GetAllTeamSpecification(int pageNumber=1,int pageSize=10)
        {
            Query.Include(p => p.Members.Where(i=>i.IsDeleted==false)).Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }
    }
}
