﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.MembersSpecification
{
    public class GetByMembersIdSpecification:Specification<Member>
    {
        public GetByMembersIdSpecification(Guid memmberId)
        {
            Query.Where(p=>p.Id==memmberId && p.IsDeleted==false);
        }
    }
}
