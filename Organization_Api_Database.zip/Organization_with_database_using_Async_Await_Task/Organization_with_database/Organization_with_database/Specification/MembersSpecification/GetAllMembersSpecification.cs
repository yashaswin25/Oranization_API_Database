﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.MembersSpecification
{
    public class GetAllMembersSpecification:Specification<Member>
    {
        public GetAllMembersSpecification(int pageNumber=1,int pageSize=10)
        {
            Query.Where(p => p.IsDeleted == false).Skip((pageNumber - 1) * pageSize).Take(pageSize);

        }
    }
}
