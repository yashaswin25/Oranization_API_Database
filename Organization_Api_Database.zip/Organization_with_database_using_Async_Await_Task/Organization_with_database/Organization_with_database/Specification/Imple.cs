﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification
{
    public class Imple:Specification<Lead>
    {
        public Imple(string city,string country,string state)
        {
            Query.Where(p=>p.LeadEnquiry.Equals(city) && p.LeadEnquiry.Equals(country) && p.LeadEnquiry.Equals(state));
        }
    }
}
