﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.OrganizationSpec
{
    public class getBYOrgnaizationIdSpecification:Specification<Organization>
    {
        public getBYOrgnaizationIdSpecification(Guid organizationId)
        {
            Query.Where(s => s.Id == organizationId).Include(p => p.Employees.Where(i=>i.IsDeleted==false)).Include(q => q.Teams).ThenInclude(r => r.Members.Where(j => j.IsDeleted == false));            
        }
    }
}