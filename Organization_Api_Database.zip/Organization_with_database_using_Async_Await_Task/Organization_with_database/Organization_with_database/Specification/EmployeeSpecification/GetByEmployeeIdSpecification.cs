﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.EmployeeSpecification
{
    public class GetByEmployeeIdSpecification : Specification<Employee>
    {
        public GetByEmployeeIdSpecification(Guid empoloyeeId)
        {
            Query.Where(p=>p.Id == empoloyeeId && p.IsDeleted==false);
        }
    }
}
