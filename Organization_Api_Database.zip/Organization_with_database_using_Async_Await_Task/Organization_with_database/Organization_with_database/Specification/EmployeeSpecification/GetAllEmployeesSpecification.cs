﻿using Ardalis.Specification;
using Organization_with_database.Models;

namespace Organization_with_database.Specification.EmployeeSpecification
{
    public class GetAllEmployeesSpecification:Specification<Employee>
    {
        public GetAllEmployeesSpecification(int pageNumber, int pageSize)
        {
            Query.Where(p => p.IsDeleted == false).Skip((pageNumber-1)*pageSize).Take(pageSize);
        }
    }
}
