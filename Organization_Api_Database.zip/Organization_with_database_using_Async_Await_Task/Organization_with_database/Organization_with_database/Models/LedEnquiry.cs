﻿namespace Organization_with_database.Models
{
    public class LedEnquiry
    {
        public string city { get; set; }    
        public string state { get; set; }
        public string country { get; set; } 
    }
}
