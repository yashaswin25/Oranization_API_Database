﻿namespace Organization_with_database.Models
{
    public class Employee:BaseEntity
    {
        public string? Name { get; set; }
        public int? Salary { get; set; }
        public int? Age { get; set; }
        public DateTime? Joining_date { get; set; }
        public Guid OrgnizationId { get; set; }
        public int? NoOfLeaves { get; set; }
    }
}
