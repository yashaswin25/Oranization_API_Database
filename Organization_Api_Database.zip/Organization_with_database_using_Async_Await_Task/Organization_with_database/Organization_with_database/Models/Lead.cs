﻿namespace Organization_with_database.Models
{
    public class Lead
    {
        public int Id { get; set; }
        public List<LedEnquiry>? LeadEnquiry { get; set; }
    }
}
