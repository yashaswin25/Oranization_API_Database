﻿namespace Organization_with_database.Models
{
    public class Organization
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public List<Employee>? Employees { get; set; } = new List<Employee>();
        public List<Team>? Teams { get; set; }
    }
}
