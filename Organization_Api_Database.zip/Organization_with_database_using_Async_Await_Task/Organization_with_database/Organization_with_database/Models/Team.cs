﻿namespace Organization_with_database.Models
{
    public class Team
    {
        public Guid Id { get; set; }
        public Guid ManagerId { get; set; }
        public string? Name { get; set; }
        public List<Member>? Members { get; set; } = new List<Member>();
        public Guid OrgnizationId { get; set; }
    }
}
