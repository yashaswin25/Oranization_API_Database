﻿namespace Organization_with_database.DTO
{
    public class EmployeesDTO
    {
        public Guid Id { get; set; }
        public string? FullName { get; set; }
        public int? Salary { get; set; }
        public int? Age { get; set; }   
        public DateTime? Joining_date { get; set; }
        public Guid OrgnizationId { get; set; }
        public int ?NoOfLeaves { get; set; }
    }
}
