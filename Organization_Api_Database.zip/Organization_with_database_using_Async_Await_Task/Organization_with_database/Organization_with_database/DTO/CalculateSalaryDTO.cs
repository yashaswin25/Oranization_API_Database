﻿namespace Organization_with_database.DTO
{
    public class CalculateSalaryDTO
    {
        public Guid EmployeeId { get; set; }
        public double? OriginalSalary { get; set; }
        public double? DeductedAmount { get; set; }
        public double? FinalSalary { get; set; }
    }
}
