﻿using Organization_with_database.Models;

namespace Organization_with_database.DTO
{
    public class OrganizationDTO
    {
        //public Guid Id { get; set; }
        public string? OrganizationName { get; set; }
        public string? Address { get; set; }
        public List<Employee>? Employees { get; set; } = new();
        public List<Team>? Teams { get; set; } = new();
    }
}
